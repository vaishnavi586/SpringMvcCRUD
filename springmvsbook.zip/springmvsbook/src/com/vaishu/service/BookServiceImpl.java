package com.vaishu.service;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;



import com.vaishu.service.BookService;
import com.vaishu.dao.BookDao;
import com.vaishu.model.Book;

@Service("bookService")
@Transactional(propagation = Propagation.SUPPORTS, readOnly = true)
public class BookServiceImpl implements BookService {

	@Autowired
	private BookDao bookDao;
	
	@Transactional(propagation = Propagation.REQUIRED, readOnly = false)
	// So a transaction with this isolation reads uncommitted data of other concurrent transactions
	public void addBook(Book book) {
		bookDao.addBook(book);
	}
	
	public List<Book> listBooks() {
		return bookDao.listBooks();
	}

	public Book getBook(int userid) {
		return bookDao.getBook(userid);
	}
	
	public void deleteBook(Book book) {
		bookDao.deleteBook(book);
	}

	

}
