package com.vaishu.bean;

import java.util.Date;

public class BookBean {
	private Integer id;
	private Integer No;
	private String name;
	private Integer issueddate;
	private Integer returndate;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public Integer getNo() {
		return No;
	}
	public void setNo(Integer no) {
		No = no;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Integer getIssueddate() {
		return issueddate;
	}
	public void setIssueddate(Integer issueddate) {
		this.issueddate = issueddate;
	}
	public Integer getReturndate() {
		return returndate;
	}
	public void setReturndate(Integer returndate) {
		this.returndate = returndate;
	}
	
}