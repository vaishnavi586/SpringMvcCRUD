package com.vaishu.dao;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.vaishu.dao.BookDao;
import com.vaishu.model.Book;

@Repository("bookDao")
public class BookDaoImpl implements BookDao {

	@Autowired
	private SessionFactory sessionFactory;
	
	public void addBook(Book book) {
		sessionFactory.getCurrentSession().saveOrUpdate(book);
	}

	@SuppressWarnings("unchecked")
	public List<Book> listBooks() {
		return (List<Book>) sessionFactory.getCurrentSession().createCriteria(Book.class).list();
	}

	public Book getBook(int bookid) {
		return (Book) sessionFactory.getCurrentSession().get(Book.class, bookid);
	}

	public void deleteBook(Book book) {
		sessionFactory.getCurrentSession().createQuery("DELETE FROM book WHERE bookid = "+book.getBookId()).executeUpdate();
	}

	

}