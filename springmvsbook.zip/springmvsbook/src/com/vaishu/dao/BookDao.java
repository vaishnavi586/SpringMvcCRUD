package com.vaishu.dao;

import java.util.List;

import com.vaishu.model.Book;

 
public interface BookDao {
	
	public void addBook(Book book);

	public List<Book> listBooks();
	
	public Book getBook(int userid);
	
	public void deleteBook(Book book);
}
