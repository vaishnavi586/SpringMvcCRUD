package com.javatpoint;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import javax.servlet.http.HttpServletRequest;  
import javax.servlet.http.HttpServletResponse;  

  
@Controller  
public class HelloWorldController {  
      
    @RequestMapping("/hello")  
    public ModelAndView helloWorld(HttpServletRequest request,HttpServletResponse res) throws IOException {  
    	PrintWriter pw=res.getWriter();
    	res.setContentType("text/html");
    	String a =request.getParameter("t1");
    	String b =request.getParameter("t2");
    	String c =request.getParameter("t3");
    	  String key=request.getParameter("t4");

    	try
    	{
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		
    		if(key.equals("insert"))
    	       {  
    	        PreparedStatement st=con.prepareStatement("insert into  empl values(?,?,?)");
    		
            st.setString(1,a);
    		st.setString(2,b);
    		st.setString(3,c);
    		st.execute();
    		return new ModelAndView("redirect:/login.jsp"); 
    		
            
           
        	}	
    	       
    		if(key.equals("update"))
    		{
    			PreparedStatement st=con.prepareStatement("update empl set Name=?,Password=? where Empnono=?");

    			st.setString(1, b);
    			st.setString(2, c);
    			st.setString(3, a);
    			
    			st.execute();
    			String message = "updated "+a;  
                return new ModelAndView("hellopage", "message",message); 
    		}
    		if(key.equals("delete"))
    		{
    			PreparedStatement st=con.prepareStatement("delete from empl where Empnono=?");


    			st.setString(1, a);
    			st.execute();
    			
    			
    			String message = "deleted "+a;  
                return new ModelAndView("hellopage", "message",message); 
    		}
    		if(key.equals("view"))
    		{
    			
    			Statement st=con.createStatement();
    			ResultSet rs=st.executeQuery("select * from empl");
    			while(rs.next())
    			{
    			String message=" table" +(rs.getString(1)+"  "+rs.getString(2)+"  "+rs.getString(3));
    			  return new ModelAndView("hellopage", "message",message); 
    			
    			}
    			
    			
    			
    			}
    			
    	
    		
			
    		
}	
        
    catch(Exception e) 
    	{
    	e.printStackTrace();
    }
    	  return new ModelAndView("error", "message","Sorry, Entry error");  
    	
    }      

  

    @RequestMapping("/login")  
    public ModelAndView welcomeWorld(HttpServletRequest request,HttpServletResponse res) throws IOException {  
    	PrintWriter pw=res.getWriter();
    	res.setContentType("text/html");
		String Name=request.getParameter("t1");

		String Password=request.getParameter("t2");
int status=0;

    	try 
    	{ 
    		Class.forName("oracle.jdbc.driver.OracleDriver");
    		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","System","1234");
    		PreparedStatement ps=con.prepareStatement("select Name,Password from empl where Name=?");
    		ps.setString(1, Name);
    	        ResultSet rs=ps.executeQuery();  
    	        while(rs.next()){  
    	        if(Name.equals(rs.getString(1))&&Password.equals(rs.getString(2)))
    	            status=1;
    	        
    	        }}
    	        catch(Exception ae)
    	        {
    	            ae.printStackTrace();
    	        }
    	        if(status==0) {
    	        	return new ModelAndView("redirect:/login.jsp");
    	    		
    	    		}else {
    	    			return new ModelAndView("redirect:/home.jsp");
    	    		}
    }}