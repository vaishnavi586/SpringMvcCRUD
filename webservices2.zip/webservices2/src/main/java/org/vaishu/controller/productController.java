package org.vaishu.controller;

import java.util.List;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.vaishu.bean.product;
import org.vaishu.service.productService;

@RestController
public class productController {
	
	productService ProductService = new productService();

	@RequestMapping(value = "/Products", method = RequestMethod.GET, headers = "Accept=application/json")
	public List<product> getproducts() {
		List<product> listOfproducts = ProductService.getAllproducts();
		return listOfproducts;
	}

	@RequestMapping(value = "/Product/{id}", method = RequestMethod.GET, headers = "Accept=application/json")
	public product getproductById(@PathVariable int id) {
		return ProductService.getproduct(id);
	}

	@RequestMapping(value = "/Products", method = RequestMethod.POST, headers = "Accept=application/json")
	public product addCountry(@RequestBody product Product) {
		return ProductService.addproduct(Product);
	}

	@RequestMapping(value = "/Products", method = RequestMethod.PUT, headers = "Accept=application/json")
	public product updateproduct(@RequestBody product Product) {
		return ProductService.updateproduct(Product);

	}

	@RequestMapping(value = "/Product/{id}", method = RequestMethod.DELETE, headers = "Accept=application/json")
	public void deleteproduct(@PathVariable("id") int id) {
		ProductService.deleteproduct(id);

	}	
}
