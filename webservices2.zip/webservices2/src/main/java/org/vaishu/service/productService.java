package org.vaishu.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import org.vaishu.bean.product;


public class productService {

 static HashMap<Integer,product>ProductIdMap=getproductIdMap();


 public productService() {
  super();

  if(ProductIdMap==null)
  {
   ProductIdMap=new HashMap<Integer,product>();
  // Creating some objects of Country while initializing
   product tvproduct=new product(1, "tv",100,25000);
   product fridgeproduct=new product(2, "fridge",100,25000);
 

ProductIdMap.put(1,tvproduct);
ProductIdMap.put(2,fridgeproduct);
  }
 }

 public List<product> getAllproducts()
 {
  List<product> Products = new ArrayList<product>(ProductIdMap.values());
  return Products;
 }

 public product getproduct(int id)
 {
  product Product= ProductIdMap.get(id);
  return Product;
 }
 public product addproduct(product Product)
 {
  Product.setId(getMaxId()+1);
 ProductIdMap.put(Product.getId(), Product);
  return Product;
 }
 
 public product updateproduct(product Product)
 {
  if(Product.getId()<=0)
   return null;
  ProductIdMap.put(Product.getId(), Product);
  return Product;

 }
 public void deleteproduct(int id)
 {
	 ProductIdMap.remove(id);
 }

 public static HashMap<Integer, product> getproductIdMap() {
  return ProductIdMap;
 }
 

 // Utility method to get max id
 public static int getMaxId()
 {   int max=0;
 for (int id:ProductIdMap.keySet()) {  
  if(max<=id)
   max=id;

 }  
 return max;
 }
}

