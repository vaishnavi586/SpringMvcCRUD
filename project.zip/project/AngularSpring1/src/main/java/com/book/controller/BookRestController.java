package com.book.controller;



import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.book.model.Book;
import com.book.util.BookUtil;
import com.book.service.IBookService;



@RestController
@RequestMapping("/rest/book")
@CrossOrigin(origins = "http://localhost:4200")
public class BookRestController {

	private Logger log = LoggerFactory.getLogger(BookRestController.class);

	@Autowired
	private IBookService service;
	@Autowired
	private BookUtil util;

	/**
	 * 1. Read JSON(Student) and convert to Object Format
	 *    Store data in Database. Return one Message.
	 */
	@PostMapping("/save")
	public ResponseEntity<String> saveBook(
			@RequestBody Book book)
	{
		log.info("Entered into method with Book data to save");

		ResponseEntity<String> resp = null;
		try {

			log.info("About to call save Operation");

			Integer id = service.saveBook(book);
			log.debug("Book saved with id "+id);

			String body = "Book '"+id+"' created";

			resp =  new ResponseEntity<String>(
					body, 
					HttpStatus.CREATED); //201

			log.info("Sucess response constructed");
		} catch (Exception e) {
			log.error("Unable to save book : problem is :"+e.getMessage());
			resp =  new ResponseEntity<String>(
					"Unable to Create Book", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}

		log.info("About to Exist save method with Response");
		return resp;
	}

	/**
	 * 2. Fetch all rows from database using Service
	 *    Sort data using name, return as JSON, 
	 *    else String message no data found.
	 *    
	 */
	@GetMapping("/all")
	public ResponseEntity<?> getAllBooks() {
		log.info("Entered into method to fetch Books data");
		ResponseEntity<?> resp = null ;
		try {

			log.info("About to call fetch book service");
			List<Book> list = service.getAllBooks();
			if(list!=null && !list.isEmpty()) {
				log.info("Data is not empty=>"+list.size());
				list.sort((b1,b2)->b1.getName().compareTo(b2.getName()));
				/* JDK 1.8
				list = list.stream()
						.sorted((s1,s2)->s1.getName().compareTo(s2.getName()))
						.collect(Collectors.toList());
				 */
				resp = new ResponseEntity<List<Book>>(list, HttpStatus.OK);
			} else {
				log.info("No Book exist: size "+list.size());

				//resp = new ResponseEntity<>(HttpStatus.NO_CONTENT);
				resp = new ResponseEntity<String>(
						"No Students Found",
						HttpStatus.OK);
			}
		} catch (Exception e) {
			log.error("Unable to fetch books : problem is :"+e.getMessage());

			resp =  new ResponseEntity<String>(
					"Unable to Fetch Books", 
					HttpStatus.INTERNAL_SERVER_ERROR); //500
			e.printStackTrace();
		}
		log.info("About to Exist fetch all method with Response");
		return resp;
	}


	/***
	 * 3. Get one student object based on ID (PathVariable). 
	 *   If Object exist then return Student object 
	 *   else provide message(String).
	 */
	@GetMapping("/one/{id}")
	public ResponseEntity<?> getOneBook(
			@PathVariable Integer id
			) 
	{
		log.info("Entered into Get one Student method");
		ResponseEntity<?> resp = null;
		try {
			log.info("About to make service call to fetch one record");
			Optional<Book> opt =  service.getOneBook(id);
			if(opt.isPresent()) {
				log.info("Book exist=>"+id);
				resp = new ResponseEntity<Book>(opt.get(), HttpStatus.OK);
				//resp = ResponseEntity.ok(opt.get());
			} else {
				log.warn("Given Book id not exist=>"+id);
				resp = new ResponseEntity<String>(
						"Book '"+id+"' not exist", 
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to process request fetch " + e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to process student fetch", 
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}


	/**
	 * 4. delete one row based on id (PathVariable)
	 *    First check given row exist or not?
	 *    if exist then call delete operation
	 *    else return  NO RECORD MESSAGE
	 *    
	 */

	@DeleteMapping("/remove/{id}")
	public ResponseEntity<String> removeBook(
			@PathVariable Integer id
			)
	{

		log.info("Entered into delete method");
		ResponseEntity<String> resp = null;

		try {

			log.info("About to make service call for data check");
			boolean exist = service.isBookExist(id);
			if(exist) {
				service.deleteBook(id);
				log.info("Book exist with given id and deleted=>"+id);
				resp = new ResponseEntity<String>(
						"Book '"+id+"' deleted",
						HttpStatus.OK);
			} else {
				log.warn("Given Book id not exist =>"+id);
				resp = new ResponseEntity<String>(
						"Book '"+id+"' not exist",
						HttpStatus.BAD_REQUEST);
			}
		} catch (Exception e) {
			log.error("Unable to perform Delete Operation =>" + e.getMessage());
			resp = new ResponseEntity<String>(
					"Unable to delete", 
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}

	/**
	 * 5. Update
	 */
	@PutMapping("/modify/{id}")
	public ResponseEntity<String> updateBook(
			@PathVariable Integer id,
			@RequestBody Book book
			)
	{
		log.info("Entered into Update method");

		ResponseEntity<String> resp =null;

		try {
			log.info("About to check given id exist or not db");
			Optional<Book> opt =  service.getOneBook(id);
			if(opt.isPresent()) {
				log.info("Student present in database");
				Book actual = opt.get();
				util.mapToActualObject(actual,book);
				service.updateBook(actual);
				resp = new ResponseEntity<String>(
						"Book '"+id+"' Updated", 
						//HttpStatus.RESET_CONTENT
						HttpStatus.OK
						);
				log.info("Book update done successfully");
			} else {
				log.info("Book not exist=>"+id);
				resp = new ResponseEntity<String>(
						"Book '"+id+"' not found", 
						//HttpStatus.RESET_CONTENT
						HttpStatus.BAD_REQUEST
						);
			}

		} catch (Exception e) {
			log.error("Unable to perform Update Operation=>" + e.getMessage() );
			resp = new ResponseEntity<String>(
					"Unable to process Update",
					HttpStatus.INTERNAL_SERVER_ERROR);
			e.printStackTrace();
		}

		return resp;
	}


}



