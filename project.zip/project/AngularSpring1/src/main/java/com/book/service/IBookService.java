package com.book.service;
	import java.util.List;
	import java.util.Optional;

	import com.book.model.Book;


	public interface IBookService {
		Integer saveBook(Book b);
		void updateBook(Book b);
		
		void deleteBook(Integer id);

		Optional<Book> getOneBook(Integer id);
		List<Book> getAllBooks();

		boolean isBookExist(Integer id);
	}

