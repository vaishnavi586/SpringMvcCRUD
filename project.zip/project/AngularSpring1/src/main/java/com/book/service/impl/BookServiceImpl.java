
package com.book.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.book.model.Book;
import com.book.repo.BookRepository;
import com.book.service.IBookService;







@Service
public class BookServiceImpl implements IBookService  {

	@Autowired
	private BookRepository repo;
	
	@Override
	public Integer saveBook(Book b) {
		b = repo.save(b);
		return b.getId();
	}

	@Override
	public void updateBook(Book b) {
		repo.save(b);
		
	}

	@Override
	public void deleteBook(Integer id) {
		repo.deleteById(id);
		
	}

	@Override
	public Optional<Book> getOneBook(Integer id) {
		return repo.findById(id);
	}

	@Override
	public List<Book> getAllBooks() {
		return repo.findAll();
	}

	@Override
	public boolean isBookExist(Integer id) {
		return repo.existsById(id);
	}
}
