package com.book.util;

import org.springframework.stereotype.Component;

import com.book.model.Book;

;
@Component
public class BookUtil {
	public void mapToActualObject(Book actual, Book book) {
		if(book.getNo()!=null)
			actual.setNo(book.getNo());
		actual.setName(book.getName());
		actual.setIssueddate(book.getIssueddate());
		if(book.getReturndate()!=null)
			actual.setReturndate(book.getReturndate());
		
	}
}
