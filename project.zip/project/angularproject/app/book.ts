export class Book {
    id: number;
    no: number;
    name: string;
    issueddate: string;
    returndate: string;
}